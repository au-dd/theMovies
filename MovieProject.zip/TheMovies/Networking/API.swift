//
//  API.swift
//  TheMovies
//
//  Created by Diana Duan on 20/7/21.
//

import Foundation

struct API {
    static let key = "98f2f9c7177d45ea5fcbe0d31c19a3ea"
}
