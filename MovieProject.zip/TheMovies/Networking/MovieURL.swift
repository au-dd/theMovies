//
//  MovieURL.swift
//  TheMovies
//
//  Created by Diana Duan on 20/7/21.
//

import Foundation

enum MovieURL: String {
    case nowPlaying = "now_playing"
    case upcoming = "upcoming"
    case popular = "popular"

    public var urlString: String {
        //"baseURL\(self.rawValue)?api_key=\(API.key)&language=en-US"
        "\(MovieReviewsManager.baseURL)\(self.rawValue)?api_key=\(API.key)&language=en-US"
    }
}
