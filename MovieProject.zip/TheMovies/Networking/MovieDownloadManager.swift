//
//  MovieDownloadManager.swift
//  TheMovies
//
//  Created by Diana Duan on 20/7/21.
//

import SwiftUI

final class MovieDownLoadManager: ObservableObject {
    @Published var movies = [Movie]()
    @Published var cast = [Cast]()

    func getNowPlaying() {
        getMovies(movieUrl: .nowPlaying)

    }

    func getUpcoming() {
        getMovies(movieUrl: .upcoming)

    }

    func getPopular() {
        getMovies(movieUrl: .popular)

    }

    func getCast(for movie: Movie) {
        let urlString = "\(MovieReviewsManager.baseURL)\(movie.id ?? 100)/credits?api_key=\(API.key)&language=en-US"
        NetworkManager<CastReponse>.fetch(from: urlString) { (result) in
            switch result {
            case .success(let response):
                self.cast = response.cast
            case .failure(let error):
                print(error)
            }
        }
    }

    private func getMovies(movieUrl: MovieURL) {
        NetworkManager<MovieResponse>.fetch(from: movieUrl.urlString) { (result) in
            switch result {
            case .success(let movieResponse):
                self.movies = movieResponse.results
            case .failure(let error):
                print(error)
            }

        }
    }
}
