//
//  DiscoverView.swift
//  TheMovies
//
//  Created by Diana Duan on 20/7/21.
//

import SwiftUI

struct DiscoverView: View {
    @State private var offset: CGFloat = 0
    @State private var index = 0

    @ObservedObject private var movieManager = MovieDownLoadManager()

    var body: some View {
        Text("Hello, Discover!")
    }
}

struct DiscoverView_Previews: PreviewProvider {
    static var previews: some View {
        DiscoverView()
    }
}
