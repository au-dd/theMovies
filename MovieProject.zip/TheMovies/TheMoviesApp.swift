//
//  TheMoviesApp.swift
//  TheMovies
//
//  Created by Diana Duan on 20/7/21.
//

import SwiftUI

@main
struct TheMoviesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
